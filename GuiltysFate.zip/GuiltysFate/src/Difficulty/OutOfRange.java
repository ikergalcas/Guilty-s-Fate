package Difficulty;

public class OutOfRange extends RuntimeException {
	public OutOfRange(String msg) {
		super(msg);
	}
}
