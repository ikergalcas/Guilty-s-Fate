package DelayTime;

public class NegativeTimeException extends RuntimeException{
		public NegativeTimeException(String message) {
		    super(message);
		}
}
