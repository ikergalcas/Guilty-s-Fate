package PopUps;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import main.GameManager;
import main.UI;

public class GameTimer {

	static int i = 240;
	private static JFrame jframe;

	public GameTimer(int time) {
		GameTimer.setJframe(new JFrame());
		i = time;
	}

	public static void gameTimer() {
		setJframe(new JFrame("Timer"));
		final JLabel jLabel = new JLabel();
		final JButton b = new JButton("Play again");
		final JButton b2 = new JButton("Exit the game");
		getJframe().setLayout(new FlowLayout());
		getJframe().setBounds(1100, 25, 400, 100);

		getJframe().add(jLabel);
		getJframe().setVisible(true);

		final Timer timer = new Timer();

		timer.scheduleAtFixedRate(new TimerTask() {
			// int i = 30;

			public void run() {

				jLabel.setText("Time left: " + i);
				i--;

				if (i < 0) {
					timer.cancel();
					jLabel.setText("Time's up! The train crashed");
					jLabel.setVisible(true);
					getJframe().add(b);
					getJframe().add(b2);
					getJframe().setBounds(500, 200, 400, 100);
					UI.window.setVisible(false);
					// Start over
					b.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							getJframe().dispose();
							i = 30;
							new GameManager();
						}
					});

					// Exit the game
					b2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							getJframe().dispose();
							System.exit(0);
						}
					});

				}
			}
		}, 0, 1000);
	}

	public static void setTime(int time) {
		i = time;
	}

	public static int getTime() {
		// TODO Auto-generated method stub
		return i;
	}

	public static JFrame getJframe() {
		return jframe;
	}

	public static void setJframe(JFrame jframe) {
		GameTimer.jframe = jframe;
	}

}
