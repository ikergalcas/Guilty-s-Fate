package PopUps;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Popup;
import javax.swing.PopupFactory;

import main.GameManager;
import main.UI;

public class WinOrLose extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static Popup p;
	static JLabel l2;

	public static void finalMessage(String l2par) {
		JFrame f = new JFrame("End of game");

//		// create a label
//		JLabel l2 = new JLabel("Game over! You lost");
//		JLabel l3= new JLabel("Congratulations! You won");
		l2 = new JLabel(l2par);

		f.setSize(400, 100);

		PopupFactory pf = new PopupFactory();

		// create a panel
		JPanel p2 = new JPanel();

		// set Background of panel
		p2.setBackground(Color.white);

		// p2.add(l);

		// create a popup
		p = pf.getPopup(f, p2, 152, 180);

		// create a button
		JButton b = new JButton("Play again");
		JButton b2 = new JButton("Exit the game");

		// Exits program if b2 pressed
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
				System.exit(0);
			}
		});

		// Restarts game if pressed
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
				UI.window.setVisible(false);
				new GameManager();
			}
		});

		JPanel p1 = new JPanel();
		JOptionPane.showMessageDialog(p1, l2);
		p1.add(b);
		p1.add(b2);
		f.add(p1);
		f.show();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		p.show();

	}

}
