package PopUps;

import java.awt.*;
import java.util.Hashtable;

import javax.swing.*;

public class LoginForm {

	String name;

	// Pantalla para meter tu usuario y contrase�a
	public void login(JFrame frame) {

		JPanel panel = new JPanel(new BorderLayout(5, 5));

		JPanel label = new JPanel(new GridLayout(0, 1, 2, 2));
		label.add(new JLabel("Name", SwingConstants.RIGHT));
		// label.add(new JLabel("Password", SwingConstants.RIGHT));
		panel.add(label, BorderLayout.WEST);

		JPanel controls = new JPanel(new GridLayout(0, 1, 2, 2));
		JTextField username = new JTextField();
		controls.add(username, BorderLayout.CENTER);

//		 JPasswordField password = new JPasswordField();
//		 controls.add(password);
		panel.add(controls, BorderLayout.CENTER);

		JOptionPane.showMessageDialog(frame, panel, "Login", JOptionPane.WARNING_MESSAGE);

		name = username.getText();
//		 System.out.print(name);

	}

	public String getName() {
		return name;
	}

}
