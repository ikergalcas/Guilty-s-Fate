package Scenary;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import Action.Action;

public class Scenery {
	private String background;
	private ArrayList<Action> actions = new ArrayList<Action>();
	int id;

	public Scenery(String bck, ArrayList<Action> ar) {
		this.background = bck;
		this.actions = ar;
	}

	public Scenery(String m) {
		this.background = m;
	}

	public void setScenery(String m, ArrayList<Action> a) {
		this.background = m;
		this.actions = a;
	}

	public String getScenery() {
		return this.background;
	}

	public ArrayList<Action> getSetOfActions() {
		return this.actions;
	}
	
	public void addAction(Action action) {
		actions.add(action);
	}

	public void actionGroup(HashSet<Action> set, int id) throws Exception {
		Boolean validId = false;
		ArrayList<Action> sol = new ArrayList<Action>();
		for (Action act : set) {
			if (act.getId() == id) {
				sol.add(act);
				validId = true;
			}
		}
		if (validId) {
			this.actions = sol;
		} else {
			throw new Exception("Invalid scenary id");
		}
	}

	private void changeBackground(String m) throws Exception {
		if (m == this.background) {
			throw new Exception("You are already in this map");
		} /*
			 * else if(Comprobar que el mapa par�metro est� en lista de mapas) throw new
			 * Exception("Can't find this map in the files");
			 */
		else {
			System.out.print("Now you are at: ");
			for (int i = 0; i < m.length() - 4; i++) {
				System.out.print(m.charAt(i));
			}
			// setScenery(m);
			// Aqui cambiamos la imagen de fondo (el mapa)
		}
	}

}
