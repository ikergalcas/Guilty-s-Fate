package main;

import javax.swing.JFrame;

import Action.Action;
import Difficulty.Difficulty;
import Scenary.Scenery;
import PopUps.GameTimer;
import PopUps.LoginForm;

public class GameManager {
	// public int time_for_game;
	
	public int difficulty;
	
	public GameTimer myTimer;

	public static Scenery[] sceneries = {new Scenery("Anden.png"), new Scenery("bg2.png"), new Scenery("Bar.png"),
			new Scenery("wagon2.png"), new Scenery("Map.png"), new Scenery("wagon2.png"), new Scenery("selectingmap.png") };

	ActionHandler aHandler = new ActionHandler(this);
	public UI ui = new UI(this);
	public static LoginForm a = new LoginForm();

	public static void main(String[] args) {
		JFrame j = new JFrame("Login Form");
		a.login(j);
		Action ac10 = new Action("Go into the train", 1);
		Action ac11 = new Action("Time", 1);
		Action ac12 = new Action("Cerrar1", 1);
		Action ac13 = new Action("Exit the game", 1);

		Action ac20 = new Action("Do nothing and keep reading the paper", 2);
		Action ac21 = new Action("Ask the reviser if he saw something suspicious", 2);
		Action ac22 = new Action("Move to the bar wagon", 2);
		Action ac23 = new Action("Make an arrest", 2);

		Action ac30 = new Action("Observe map of train.", 3);
		Action ac31 = new Action("Talk to the bartender.", 3);
		Action ac32 = new Action("Move to the passenger wagon.", 3);
		Action ac33 = new Action("Make an arrest", 3);

		Action ac40 = new Action("Go to the bathroom", 4);
		Action ac41 = new Action("Talk to the doctor.", 4);
		Action ac42 = new Action("Try to enter control room.", 4);
		Action ac43 = new Action("Make an arrest", 4);
		
		Action ac60 = new Action("Easy (3 minutes)", 5);
		Action ac61 = new Action("Medium (2 minutes)", 5);
		Action ac62 = new Action("Hard (1 minute)", 5);
		Action ac63 = new Action("Coming soon...", 5);
		
		Action volverMapa = new Action("Return to wagon.", 6);

		sceneries[0].addAction(ac10);
		sceneries[0].addAction(ac11);
		sceneries[0].addAction(ac12);
		sceneries[0].addAction(ac13);
		sceneries[1].addAction(ac20);
		sceneries[1].addAction(ac21);
		sceneries[1].addAction(ac22);
		sceneries[1].addAction(ac23);
		sceneries[2].addAction(ac30);
		sceneries[2].addAction(ac31);
		sceneries[2].addAction(ac32);
		sceneries[2].addAction(ac33);
		sceneries[5].addAction(ac40);
		sceneries[5].addAction(ac41);
		sceneries[5].addAction(ac42);
		sceneries[5].addAction(ac43);
		sceneries[6].addAction(ac60);
		sceneries[6].addAction(ac61);
		sceneries[6].addAction(ac62);
		sceneries[6].addAction(ac63);
		sceneries[4].addAction(volverMapa);

		// pop start = new pop();

		// Difficulty dificultad = new Difficulty();
		// dificultad.selectDifficultyGraphical();

		new GameManager();
	}

	public GameManager() {
	}
}
