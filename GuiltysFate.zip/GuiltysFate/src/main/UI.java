package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.MenuItem;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
import javax.swing.Popup;

import Action.Action;
import PopUps.GameTimer;
import PopUps.WinOrLose;

public class UI {

	GameManager gm;

	public static JFrame window;

	JFrame inculpar;

	JFrame perder;

	public JTextArea messagePerder;

	public JTextArea messageInculpar;

	public JTextArea messageText;
	// 1 JPanel por background("fondo")
	public JPanel bgPanel[] = new JPanel[10];
	public JLabel bgLabel[] = new JLabel[10];

	public UI(GameManager gm) {
		this.gm = gm;

		createMainField();
		generateScene();

		window.setVisible(true);
	}

	public void createMainField() {
		window = new JFrame("Guilty's Fate");
		window.setSize(800, 600);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.getContentPane().setBackground(Color.BLACK);
		window.setLayout(null);

		messageText = new JTextArea("Choose your map and difficulty");
		// Situar caja texto (posx,posy,base,altura)
		messageText.setBounds(50, 410, 700, 120);
		// Color Fondo texto
		messageText.setBackground(Color.BLACK);
		// Color letra
		messageText.setForeground(Color.WHITE);
		// Desea que se pueda modificar texto
		messageText.setEditable(false);
		//
		messageText.setLineWrap(true);
		messageText.setWrapStyleWord(true);
		messageText.setFont(new Font("Book Antiqua", Font.PLAIN, 23));
		window.add(messageText);
	}

	public void generateinculpar() {

		GameTimer.getJframe().dispose();
		inculpar = new JFrame();
		inculpar.setSize(800, 600);
		inculpar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		inculpar.getContentPane().setBackground(Color.white);
		inculpar.setLayout(null);

		messageInculpar = new JTextArea(
				"You have to choose who killed the victim: \n\n\n        Revisor:                        Doctor:                     Bartender: ");
		messageInculpar.setBounds(20, 20, 700, 120);
		messageInculpar.setBackground(Color.white);
		messageInculpar.setForeground(Color.black);
		messageInculpar.setEditable(false);

		messageInculpar.setLineWrap(true);
		messageInculpar.setWrapStyleWord(true);
		messageInculpar.setFont(new Font("Book Antiqua", Font.PLAIN, 26));
		inculpar.add(messageInculpar);

		JPanel panelPrincipal = new JPanel();
		panelPrincipal.setBounds(40, 140, 700, 350);
		panelPrincipal.setBackground(Color.white);
		panelPrincipal.setLayout(null);

		inculpar.add(panelPrincipal);

		JLabel aniadir = new JLabel();
		aniadir.setBounds(0, 0, 700, 400);

		JLabel objectLabelRevisor = new JLabel();
		objectLabelRevisor.setBounds(10, 10, 200, 200);
		ImageIcon objectIcon = new ImageIcon(getClass().getClassLoader().getResource("images/revisor.png"));
		objectLabelRevisor.setIcon(objectIcon);
		panelPrincipal.add(objectLabelRevisor);

		JLabel objectLabelDoctor = new JLabel();
		objectLabelDoctor.setBounds(270, 10, 200, 200);
		objectLabelDoctor.setIcon(new ImageIcon(getClass().getClassLoader().getResource("images/doctor.png")));
		panelPrincipal.add(objectLabelDoctor);

		JLabel objectLabelBartender = new JLabel();
		objectLabelBartender.setBounds(530, 10, 200, 200);
		objectLabelBartender.setIcon(new ImageIcon(getClass().getClassLoader().getResource("images/bartender.png")));
		panelPrincipal.add(objectLabelBartender);

		objectLabelRevisor.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				UI.window.setVisible(false);
				gm.ui.inculpar.dispose();
				String l2 = "Congratulations! You caught the murderer and were able to stop the train before crashing";
				WinOrLose.finalMessage(l2);

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		objectLabelDoctor.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				gm.ui.inculpar.setVisible(false);
				gm.ui.generateperdiste("You arrested the wrong person, the Doctor was not the killer! The train crashed.");

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		objectLabelBartender.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				gm.ui.inculpar.setVisible(false);
				gm.ui.generateperdiste("You arrested the wrong person, the Bartender was not the killer! The train crashed.");

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});
		panelPrincipal.add(aniadir);

	}

	public void createBackground(int bgNum, String bgFileName) {

		bgPanel[bgNum] = new JPanel();
		bgPanel[bgNum].setBounds(50, 0, 700, 400);
		bgPanel[bgNum].setBackground(Color.black);
		bgPanel[bgNum].setLayout(null);
		window.add(bgPanel[bgNum]);

		bgLabel[bgNum] = new JLabel();
		bgLabel[bgNum].setBounds(0, 0, 700, 400);

		ImageIcon bgIcon = new ImageIcon(getClass().getClassLoader().getResource(bgFileName));
		bgLabel[bgNum].setIcon(bgIcon);

	}

	public void createObject3(int bgNum, int objx, int objy, int objanchura, int objaltura, String objFileName,
			Action nombreaccion1, Action nombreaccion2, Action nombreaccion3, String decision1, String decision2,
			String decision3) {

		JPopupMenu popMenu = new JPopupMenu();

		// 4 Acciones [1][2]][3][4]>>>> 4+1=5------------------
		JMenuItem menuItem[] = new JMenuItem[5];

		// Accion 1
		menuItem[1] = new JMenuItem(nombreaccion1.getName());
		menuItem[1].addActionListener(gm.aHandler);
		menuItem[1].setActionCommand(decision1);
		popMenu.add(menuItem[1]);

		// Accion 2
		menuItem[2] = new JMenuItem(nombreaccion2.getName());
		menuItem[2].addActionListener(gm.aHandler);
		menuItem[2].setActionCommand(decision2);
		popMenu.add(menuItem[2]);
		// Accion 3
		menuItem[3] = new JMenuItem(nombreaccion3.getName());
		menuItem[3].addActionListener(gm.aHandler);
		menuItem[3].setActionCommand(decision3);
		popMenu.add(menuItem[3]);

		// --------------------------------------------
		JLabel objectLabel = new JLabel();
		// Situar caja texto (posx,posy,base,altura)
		objectLabel.setBounds(objx, objy, objanchura, objaltura);

		ImageIcon objectIcon = new ImageIcon(getClass().getClassLoader().getResource(objFileName));
		objectLabel.setIcon(objectIcon);

		objectLabel.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				popMenu.show(objectLabel, e.getX(), e.getY());

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		bgPanel[bgNum].add(objectLabel);
		// El fondo se a�ade lo ultimo(abajo)

	}

	public void createObject(int bgNum, int objx, int objy, int objanchura, int objaltura, String objFileName,
			Action nombreaccion1, Action nombreaccion2, Action nombreaccion3, Action nombreaccion4, String decision1,
			String decision2, String decision3, String decision4) {

		JPopupMenu popMenu = new JPopupMenu();

		// 4 Acciones [1][2]][3][4]>>>> 4+1=5------------------
		JMenuItem menuItem[] = new JMenuItem[5];

		// Accion 1
		menuItem[1] = new JMenuItem(nombreaccion1.getName());
		menuItem[1].addActionListener(gm.aHandler);
		menuItem[1].setActionCommand(decision1);
		popMenu.add(menuItem[1]);

		// Accion 2
		menuItem[2] = new JMenuItem(nombreaccion2.getName());
		menuItem[2].addActionListener(gm.aHandler);
		menuItem[2].setActionCommand(decision2);
		popMenu.add(menuItem[2]);
		// Accion 3
		menuItem[3] = new JMenuItem(nombreaccion3.getName());
		menuItem[3].addActionListener(gm.aHandler);
		menuItem[3].setActionCommand(decision3);
		popMenu.add(menuItem[3]);
		// Accion 4
		menuItem[4] = new JMenuItem(nombreaccion4.getName());
		menuItem[4].addActionListener(gm.aHandler);
		menuItem[4].setActionCommand(decision4);
		popMenu.add(menuItem[4]);

		// --------------------------------------------
		JLabel objectLabel = new JLabel();
		// Situar caja texto (posx,posy,base,altura)
		objectLabel.setBounds(objx, objy, objanchura, objaltura);

		ImageIcon objectIcon = new ImageIcon(getClass().getClassLoader().getResource(objFileName));
		objectLabel.setIcon(objectIcon);

		objectLabel.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				popMenu.show(objectLabel, e.getX(), e.getY());

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		bgPanel[bgNum].add(objectLabel);
		// El fondo se a�ade lo ultimo(abajo)

	}

	public void generateScene() {

		createBackground(1, GameManager.sceneries[6].getScenery());
		createObject(1, 30, 15, 300, 175, "", GameManager.sceneries[6].getSetOfActions().get(0),
				GameManager.sceneries[6].getSetOfActions().get(1), GameManager.sceneries[6].getSetOfActions().get(2),
				new Action(), "Easy", "Medium", "Hard", "");
		createObject(1, 30, 190, 300, 175, "", GameManager.sceneries[6].getSetOfActions().get(3), new Action(),
				new Action(), new Action(), "", "", "", "");
		createObject(1, 330, 15, 300, 175, "", GameManager.sceneries[6].getSetOfActions().get(3), new Action(),
				new Action(), new Action(), "", "", "", "");
		createObject(1, 330, 190, 300, 175, "", GameManager.sceneries[6].getSetOfActions().get(3), new Action(),
				new Action(), new Action(), "", "", "", "");

		bgPanel[1].add(bgLabel[1]);

		// Screen 1
		createBackground(2, GameManager.sceneries[0].getScenery());
		// numScreen,posx,posy,objanchura,objaltura,nombrearchivo
		createObject3(2, 660, 320, 50, 50, "images/Button.png", GameManager.sceneries[0].getSetOfActions().get(0),
				GameManager.sceneries[0].getSetOfActions().get(1), GameManager.sceneries[0].getSetOfActions().get(3),
				"Abrir2", "Correr2", "Salir2");

		bgPanel[2].add(bgLabel[2]);

		createBackground(3, GameManager.sceneries[1].getScenery());
		createObject(3, 660, 320, 50, 50, "images/Button.png", GameManager.sceneries[1].getSetOfActions().get(0),
				GameManager.sceneries[1].getSetOfActions().get(1), GameManager.sceneries[1].getSetOfActions().get(2),
				GameManager.sceneries[1].getSetOfActions().get(3), "Nothing", "AskRevisor", "GoBarWagon", "MakeArrest");

		bgPanel[3].add(bgLabel[3]);

		createBackground(4, GameManager.sceneries[2].getScenery());
		createObject(4, 660, 320, 50, 50, "images/Button.png", GameManager.sceneries[2].getSetOfActions().get(0),
				GameManager.sceneries[2].getSetOfActions().get(1), GameManager.sceneries[2].getSetOfActions().get(2),
				GameManager.sceneries[2].getSetOfActions().get(3), "MapBack", "TalkBartender", "GoPassengerWagon",
				"MakeArrest");
		bgPanel[4].add(bgLabel[4]);

		createBackground(5, GameManager.sceneries[3].getScenery());
		createObject(5, 660, 320, 50, 50, "images/Button.png", GameManager.sceneries[5].getSetOfActions().get(0),
				GameManager.sceneries[5].getSetOfActions().get(1), GameManager.sceneries[5].getSetOfActions().get(2),
				GameManager.sceneries[5].getSetOfActions().get(3), "GoBathroom", "TalkDoctor", "TryControlRoom",
				"MakeArrest");

		bgPanel[5].add(bgLabel[5]);

		createBackground(6, GameManager.sceneries[4].getScenery());
		createObject(6, 660, 320, 50, 50, "images/Button.png", GameManager.sceneries[4].getSetOfActions().get(0), new Action(),
				new Action(), new Action(), "VolverDeMapa", "", "", "");
		bgPanel[6].add(bgLabel[6]);

	}

	public void generateperdiste(String l2) {
		UI.window.setVisible(false);
		WinOrLose.finalMessage(l2);
	}
}
