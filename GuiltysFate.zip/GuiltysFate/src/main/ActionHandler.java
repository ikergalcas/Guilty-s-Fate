package main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import PopUps.LoginForm;
import PopUps.WinOrLose;

import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Difficulty.Difficulty;
import PopUps.GameTimer;

public class ActionHandler implements ActionListener {

	GameManager gm;

	public ActionHandler(GameManager gm) {
		this.gm = gm;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		String yourChoice = e.getActionCommand();
		// "Hablar2","Abrir2","Correr2","Salir2"
		switch (yourChoice) {
		case "Abrir2":
			if(GameTimer.getTime() / 60 == 1) {
				gm.ui.messageText.setText("Reviser: Excuse me detective " + GameManager.a.getName()
				+ ", there is a problem. The machinist has been murdered and the killer has taken the key to the control room. We need to find him to be able to get in the room and stop the train. We have "
				+ String.valueOf((GameTimer.getTime() / 60)) + " minute before crashing.");
			} else {
				gm.ui.messageText.setText("Reviser: Excuse me detective " + GameManager.a.getName()
				+ ", there is a problem. The machinist has been murdered and the killer has taken the key to the control room. We need to find him to be able to get in the room and stop the train. We have "
				+ String.valueOf((GameTimer.getTime() / 60)) + " minutes before crashing.");
			}
			GameTimer.gameTimer();
			gm.ui.bgPanel[2].setVisible(false);
			gm.ui.bgPanel[3].setVisible(true);
			break;
		case "Correr2":
			if(GameTimer.getTime() / 60 == 1) {
				gm.ui.messageText.setText(
						"You will have " + String.valueOf(GameTimer.getTime() / 60) + " minute to solve the game");
			} else {
				gm.ui.messageText.setText(
						"You will have " + String.valueOf(GameTimer.getTime() / 60) + " minutes to solve the game");
			}
			break;
		case "Salir2":
			System.exit(0);
			break;
		case "Nothing":
			GameTimer.getJframe().dispose();
			gm.ui.generateperdiste("You lost! You did nothing and the train crashed.");
			/*
			 * gm.ui.messagePerder.setBounds(70, 200, 650, 200); gm.ui.messagePerder.
			 * setText("GAME OVER...\nThe train crashes and the murderer gets away.");
			 */
			// gm.ui.window.setVisible(false);
			// gm.ui.perder.setVisible(true);
			// GameTimer.setTime();
			break;
		case "AskRevisor":
			gm.ui.messageText.setText(
					"Reviser: I haven't seen anything. But the only one with access to knifes is the bartender. Also he can escape through a trapdoor in the bar before the train crashes");
			break;
		case "GoBarWagon":
			gm.ui.messageText.setText("You are now in the bar wagon.");
			gm.ui.bgPanel[3].setVisible(false);
			gm.ui.bgPanel[4].setVisible(true);
			break;
		case "MakeArrest":
			UI.window.setVisible(false);
			gm.ui.generateinculpar();
			gm.ui.inculpar.setVisible(true);
			break;
		case "MapBack":
			gm.ui.messageText.setText("This is the map.");
			for (int i = 1; i < 6; i++) {
				gm.ui.bgPanel[i].setVisible(false);
			}
			gm.ui.bgPanel[6].setVisible(true);

			break;
		case "TalkBartender":
			gm.ui.messageText.setText(
					"Oh, hi detective! Is something going on? I have just been cleaning the dishes and serving the doctor who's very deppresed, he is on the next wagon. In case it is of any help, a knife dissapeared when I wasn't looking but I don't know who took it.");
			break;
		case "GoPassengerWagon":
			gm.ui.messageText.setText("You are now in the Passenger Wagon.");
			gm.ui.bgPanel[4].setVisible(false);
			gm.ui.bgPanel[5].setVisible(true);
			break;
		case "GoBathroom":
			gm.ui.messageText.setText("You don't have enough time to go to the bathroom now! You only have "
					+ String.valueOf(GameTimer.getTime()) + " seconds left.");
			break;

		case "TalkDoctor":
			gm.ui.messageText.setText(
					"Doctor: Hello detective, I have been drinking my problems away during most of the trip and talking to the bartender, he was very upset because someone stole his favourite knife. He looks like a troubled man, I wouldn't trust him if I were you. ");
			break;

		case "TryControlRoom":
			gm.ui.messageText.setText(
					"The door is closed and there is no other door or window. There is no way of looking inside the room. How did the reviser know the machinist was murdered?.");
			break;

		case "GoLuggageWagon":
			gm.ui.messageText.setText("You are now in the luggage wagon.");
			gm.ui.bgPanel[4].setVisible(false);
			gm.ui.bgPanel[3].setVisible(true);
			break;
		case "CulparRevisor":
			UI.window.setVisible(false);
			gm.ui.inculpar.dispose();
			String l2 = "Congratulations! You won";
			WinOrLose.finalMessage(l2);
			// gm.ui.messageInculpar.setText("YES, Congratulations, the revisor was the
			// killer.");
			break;

		case "CulparBartender":
			// gm.ui.messageInculpar.setText("No, you failed, the Bartender was not the
			// killer.");
			gm.ui.inculpar.setVisible(false);
			gm.ui.generateperdiste("No, you failed, the Bartender was not the killer! The train crashed.");
			break;
		case "CulparDoctor":
			// gm.ui.messageInculpar.setText("No, you failed, the Doctor was not the
			// killer.");
			gm.ui.inculpar.setVisible(false);
			gm.ui.generateperdiste("No, you failed, the Doctor was not the killer! The train crashed.");
			break;

		case "Easy":
			gm.difficulty = 0;
			gm.ui.messageText.setText(
					"You are a well known detective on your way to your next case in London. You have to be careful because there are lots of people with reasons to hate you.");
			gm.myTimer = new GameTimer(180);
			gm.ui.bgPanel[1].setVisible(false);
			gm.ui.bgPanel[2].setVisible(true);
			break;
		case "Medium":
			gm.difficulty = 1;
			gm.ui.messageText.setText(
					"You are a well known detective on your way to your next case in London. You have to be careful because there are lots of people with reasons to hate you.");
			gm.myTimer = new GameTimer(120);
			gm.ui.bgPanel[1].setVisible(false);
			gm.ui.bgPanel[2].setVisible(true);
			break;
		case "Hard":
			gm.difficulty = 2;
			gm.ui.messageText.setText(
					"You are a well known detective on your way to your next case in London. You have to be careful because there are lots of people with reasons to hate you.");
			gm.myTimer = new GameTimer(60);
			gm.ui.bgPanel[1].setVisible(false);
			gm.ui.bgPanel[2].setVisible(true);
			break;

		case "VolverDeMapa":
			gm.ui.messageText.setText("You are now in the bar wagon.");
			gm.ui.bgPanel[6].setVisible(false);
			gm.ui.bgPanel[4].setVisible(true);
		}
	}

}
// "GoBathroom","TalkDoctor","TryControlRoom"
